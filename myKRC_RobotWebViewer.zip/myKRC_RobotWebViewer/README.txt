myKRC_RobotWebViewer with node.js, three.js and nodes7

based on the "Web-3D-HMI-Demo" by Thomas Wiens: https://github.com/thomas-v2

#################################################################

Start the application with: node mykrc-robot-web-viewer-app.js

To view the robot, open a Webbrowser with the URL:
https://<your ip address>:5501/index.html
https://127.0.0.1:5501/index.html
https://localhost:5501/index.html

#################################################################

Using Node.js: https://nodejs.org/en/
Using nodeS7 for accessing variables from a S7 plc: https://www.npmjs.com/package/nodes7
Using three.js to create the 3D graphics: https://threejs.org/
The robot model dummies are based on a KUKA KR30 R2100